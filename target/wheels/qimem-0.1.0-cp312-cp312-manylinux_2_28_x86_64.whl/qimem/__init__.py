from .qimem import *

__doc__ = qimem.__doc__
if hasattr(qimem, "__all__"):
    __all__ = qimem.__all__